package com.example.giftrecommendation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;

import com.google.android.material.navigation.NavigationView;

public class Agegenderselectscreen extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    AutoCompleteTextView age, gender;
    ArrayAdapter<String> adapterage, adaptergender;
    String[] ages, genders;
    Button continue_button;

    private DrawerLayout drawer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agegenderselectscreen);

        continue_button = findViewById(R.id.continue_button);

        //tool bar and nav menu
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        drawer = findViewById(R.id.drawer_layout);

        ImageView menuIcon = (ImageView) findViewById(R.id.profile_pic);
        menuIcon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });

//        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(Agegenderselectscreen.this,
//                drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
//        drawer.addDrawerListener(toggle);
//        toggle.syncState();

        menuIcon.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);






        ages = new String[]{"0-10", "10-15", "15-20", "20-30", "50 and above"};
        age = (AutoCompleteTextView) findViewById(R.id.select_age);
        adapterage = new ArrayAdapter<String>(Agegenderselectscreen.this,R.layout.list_item, ages);
        age.setAdapter(adapterage);

        genders = new String[]{"Male", "Female", "Others"};
        gender = findViewById(R.id.select_gender);
        adaptergender = new ArrayAdapter<>(Agegenderselectscreen.this, R.layout.list_item, genders);
        gender.setAdapter(adaptergender);

        continue_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Agegenderselectscreen.this, Viewgifts.class));
            }
        });


    }

    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.settings:
                startActivity(new Intent(Agegenderselectscreen.this, Settings.class));
                break;
            case R.id.calender:
                startActivity(new Intent(Agegenderselectscreen.this, Calender.class));
                break;
            case R.id.order_placed:
                startActivity(new Intent(Agegenderselectscreen.this, Orderplaced.class));
                break;
            case R.id.logout:

                break;



        }

        return true;
    }
}